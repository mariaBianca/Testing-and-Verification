package main;

import static org.junit.Assert.*;

import org.junit.Test;

public class CarTest {

	@Test
	public void carisParked() {
		Car car = new Car(null, null, 0, false, false);
		car.park();
		Boolean result = car.whereIs().getParkingStatus();
		assertNotNull(result);
		assertEquals((car.whereIs().getParkingSpots() == true) ,result);
	}

}
